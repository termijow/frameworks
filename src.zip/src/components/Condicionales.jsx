
export default function Condicionales() {
  return (
    <>
    <h2>ola</h2>
    <p>asdasda</p>
    </>
  );
}
