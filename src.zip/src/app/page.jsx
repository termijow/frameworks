import RenderizadoComponentes from "@/components/RenderizadoComponentes";

export default function Home() {
  return (
    <>
      <RenderizadoComponentes/>
    </>
  );
}
